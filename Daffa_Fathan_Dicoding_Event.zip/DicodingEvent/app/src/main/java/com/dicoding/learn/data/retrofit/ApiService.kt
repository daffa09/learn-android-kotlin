package com.dicoding.learn.data.retrofit

import com.dicoding.learn.data.response.UpcomingResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("events?active=1")
    fun getUpcomingEvent() : Call<UpcomingResponse>

    @GET("events?active=0")
    fun getFinishedEvent() : Call<UpcomingResponse>

    @GET("events")
    fun getUpcomingEvent(@Query("active") active: Int = -1, @Query("q") query: String): Call<UpcomingResponse>

}