package com.dicoding.learn.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import com.bumptech.glide.Glide
import com.dicoding.learn.R
import com.dicoding.learn.data.response.ListEventsItem
import com.dicoding.learn.databinding.ActivityEventDetailBinding

class EventDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEventDetailBinding

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEventDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.progressBar.visibility = View.VISIBLE

        val event = intent.getSerializableExtra("EVENT") as ListEventsItem


        supportActionBar?.title = event.name
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding.eventName.text = event.name
        binding.eventOwnerName.text = event.ownerName
        binding.eventTime.text = "${event.beginTime} - ${event.endTime}"
        val sisaQuota = event.quota?.minus(event.registrants!!)
        binding.eventQuota.text = "Sisa kuota: $sisaQuota"
        event.description?.let { setupHtmlDescription(it) }

        Glide.with(this)
            .load(event.imageLogo)
            .placeholder(R.drawable.baseline_image_24)
            .into(binding.eventImage)

        binding.progressBar.visibility = View.GONE

        binding.buttonRegister.setOnClickListener {
            val registerLink = event.link
            if (!registerLink.isNullOrEmpty()) {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(registerLink))
                startActivity(intent)
            } else {
                Toast.makeText(this, "Invalid registration link", Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun setupHtmlDescription(htmlContent: String) {
        binding.eventDescription.text = HtmlCompat.fromHtml(htmlContent, HtmlCompat.FROM_HTML_MODE_LEGACY)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
