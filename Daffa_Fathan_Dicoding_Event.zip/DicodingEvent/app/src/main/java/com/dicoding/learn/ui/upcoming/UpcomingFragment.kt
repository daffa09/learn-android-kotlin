package com.dicoding.learn.ui.upcoming

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.learn.databinding.FragmentUpcomingBinding


class UpcomingFragment : Fragment() {

    private var _binding: FragmentUpcomingBinding? = null
    private val binding get() = _binding!!

    private lateinit var eventsAdapter: UpcomingEventAdapter
    private lateinit var upcomingViewModel: UpcomingViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentUpcomingBinding.inflate(inflater, container, false)
        val root: View = binding.root

        eventsAdapter = UpcomingEventAdapter()
        binding.rvUpcomingEvent.adapter = eventsAdapter

        upcomingViewModel = ViewModelProvider(this).get(UpcomingViewModel::class.java)

        binding.rvUpcomingEvent.layoutManager = LinearLayoutManager(requireContext())

        upcomingViewModel.listEvent.observe(viewLifecycleOwner) { events ->
            eventsAdapter.submitList(events)
        }

        upcomingViewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            if (isLoading) {
                binding.progressBar.visibility = View.VISIBLE
                binding.rvUpcomingEvent.visibility = View.GONE
            } else {
                binding.progressBar.visibility = View.GONE
                binding.rvUpcomingEvent.visibility = View.VISIBLE
            }
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
